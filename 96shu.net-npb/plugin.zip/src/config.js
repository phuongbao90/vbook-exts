let BASE_URL = "https://96shu.net";
try {
  if (CONFIG_URL) {
    BASE_URL = CONFIG_URL;
  }
} catch (error) {}
